// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
    'use strict'
  
    window.addEventListener('load', function () {
      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.getElementsByClassName('needs-validation')
  
      // Loop over them and prevent submission
      Array.prototype.filter.call(forms, function (form) {
        form.addEventListener('submit', function (event) {
          if (form.checkValidity() === false) {
            event.preventDefault()
            event.stopPropagation()
          }
          form.classList.add('was-validated')
        }, false)
      })
    }, false)
  }())
  focusMethod = function getFocus() {           
    document.getElementById("firstName").focusout();
  }
 /* $(document).on('click','#firstName',function() {
    if($('input.getFocus').focusout()) { var p=$(this).attr('name'); alert(p); }
});*/
document.getElementById('firstName').focusout = function(e) {
    var evt = e || window.event, // IE workaround
         target = evt.target || evt.srcElement // IE workaround again
   
    if (target.value !==""){ // Si la valeur est ce que tu veux
      target.focusout// Tu actives l'input suivant
    }
  }